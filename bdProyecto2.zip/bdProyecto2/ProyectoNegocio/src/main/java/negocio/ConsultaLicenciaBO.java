package negocio;

/**
 *
 * @author ruben
 */
import dto.LicenciaDTO;

public class ConsultaLicenciaBO implements IConsultaLicenciaBO {
 
// Método para consultar una licencia por su ID
    @Override
    public LicenciaDTO consultarLicenciaPorId(Long id) {

        return null;
    }
}
