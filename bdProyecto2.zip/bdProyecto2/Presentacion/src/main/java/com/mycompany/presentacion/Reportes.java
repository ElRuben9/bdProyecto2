/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.presentacion;

import dto.ReporteTramite;
import entidadesJPA.Tramite;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author diana
 */
public class Reportes extends javax.swing.JFrame {

    private List<Tramite> tramites;

    /**
     * Creates new form Reportes
     */
     public Reportes() {
        initComponents();
        // ActionListener para el botón Regresar
        botonRegresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana actual (Reportes)
                new Inicio().setVisible(true); // Crear una nueva instancia de la clase Inicio y hacerla visible
            }
        });
        tramites = obtenerTramitesDesdeBaseDeDatos(); // Obtener los trámites desde la base de datos
        mostrarTabla(); // Mostrar los datos en la tabla de trámites
    }

    /**
     * Método para obtener los trámites desde la base de datos
     */
    private List<Tramite> obtenerTramitesDesdeBaseDeDatos() {
        // Aquí iría la lógica para obtener los trámites desde la base de datos
        // Por ahora, solo devolvemos una lista vacía como ejemplo
        return new ArrayList<>();
    }

    /**
     * Método para mostrar los datos en la tabla de trámites
     */
    private void mostrarTabla() {
        DefaultTableModel modeloTabla = new DefaultTableModel();
        Object[] datosTabla = new Object[5];
        modeloTabla.addColumn("Tipo de trámite");
        modeloTabla.addColumn("Fecha Expedición");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Costo");

        if (!tramites.isEmpty()) {
            for (int i = 0; i < tramites.size(); i++) {
                datosTabla[0] = tramites.get(i).getTipoTramite();
                datosTabla[1] = tramites.get(i).getFechaTramite();
                datosTabla[2] = tramites.get(i).getPersona().getNombre() + " " + tramites.get(i).getPersona().getApellidoPaterno() + " " + tramites.get(i).getPersona().getApellidoMaterno();
                datosTabla[3] = "$" + tramites.get(i).getCosto();
                modeloTabla.addRow(datosTabla);
            }
            tablaReporte.setModel(modeloTabla);
        }
    }

    /**
     * Método para formatear una fecha en formato de cadena
     */
    private String fechaEnFormato(Calendar calendar) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        return sdf.format(calendar.getTime());
    }


     private void generarPDF() {
        try {
            List<ReporteTramite> datosReporte = convertirTramitesAReportes(tramites);
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(datosReporte);

            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ColeccionBeanParametro", dataSource);

            InputStream input = getClass().getResourceAsStream("/JasperReport_A4.jrxml");

            JasperDesign jasperDesign = JRXmlLoader.load(input);

            JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            viewer.setVisible(true);

        } catch (Exception e) {
            JOptionPane.showConfirmDialog(this, "Error al generar el reporte", "Error del sistema", JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
        }
    }
    // Método para convertir los trámites a objetos de tipo ReporteTramite
    private List<ReporteTramite> convertirTramitesAReportes(List<Tramite> tramites) {
        List<ReporteTramite> reportes = new ArrayList<>();
        for (Tramite tramite : tramites) {
            ReporteTramite reporte = new ReporteTramite();
            reporte.setTipoTramite(tramite.getTipoTramite());
            reporte.setFechaExpedicion(tramite.getFechaTramite());
            reporte.setNombre(tramite.getPersona().getNombre() + " " + tramite.getPersona().getApellidoPaterno() + " " + tramite.getPersona().getApellidoMaterno());
            reporte.setCosto(tramite.getCosto());
            reportes.add(reporte);
        }
        return reportes;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        txtPeriodo = new javax.swing.JLabel();
        periodoDesde = new javax.swing.JComboBox<>();
        periodoHasta = new javax.swing.JComboBox<>();
        txtTipoTramite = new javax.swing.JLabel();
        tipoTramite = new javax.swing.JComboBox<>();
        txtNombreSimilar = new javax.swing.JLabel();
        nombreSimilar = new javax.swing.JTextField();
        botonBuscar = new javax.swing.JButton();
        botonLimpiar = new javax.swing.JButton();
        botonGenerarPDF = new javax.swing.JButton();
        botonRegresar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaReporte = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(101, 118, 136));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Book Antiqua", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Reportes");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        jTextField1.setBackground(new java.awt.Color(218, 184, 87));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 610, 60));

        txtPeriodo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtPeriodo.setText("Periodo:");
        jPanel1.add(txtPeriodo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, -1, -1));

        periodoDesde.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A" }));
        jPanel1.add(periodoDesde, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        periodoHasta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(periodoHasta, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, -1, -1));

        txtTipoTramite.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtTipoTramite.setText("Tipo de tramite:");
        jPanel1.add(txtTipoTramite, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, -1, -1));

        tipoTramite.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(tipoTramite, new org.netbeans.lib.awtextra.AbsoluteConstraints(422, 150, 110, -1));

        txtNombreSimilar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtNombreSimilar.setText("Nombre Similar:");
        jPanel1.add(txtNombreSimilar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, -1, -1));
        jPanel1.add(nombreSimilar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 220, 240, -1));

        botonBuscar.setBackground(new java.awt.Color(160, 11, 43));
        botonBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        botonBuscar.setForeground(new java.awt.Color(255, 255, 255));
        botonBuscar.setText("Buscar");
        botonBuscar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(botonBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, 90, 30));

        botonLimpiar.setBackground(new java.awt.Color(160, 11, 43));
        botonLimpiar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        botonLimpiar.setForeground(new java.awt.Color(255, 255, 255));
        botonLimpiar.setText("Limpiar");
        botonLimpiar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(botonLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 270, -1, 30));

        botonGenerarPDF.setBackground(new java.awt.Color(160, 11, 43));
        botonGenerarPDF.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        botonGenerarPDF.setForeground(new java.awt.Color(255, 255, 255));
        botonGenerarPDF.setText("Generar PDF");
        botonGenerarPDF.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonGenerarPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGenerarPDFActionPerformed(evt);
            }
        });
        jPanel1.add(botonGenerarPDF, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 270, -1, -1));

        botonRegresar.setBackground(new java.awt.Color(160, 11, 43));
        botonRegresar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        botonRegresar.setForeground(new java.awt.Color(255, 255, 255));
        botonRegresar.setText("Regresar");
        botonRegresar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(botonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 460, 140, 30));

        tablaReporte.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Reporte"
            }
        ));
        jScrollPane2.setViewportView(tablaReporte);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, 390, 110));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonLimpiarActionPerformed

    private void botonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegresarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonRegresarActionPerformed

    private void botonGenerarPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGenerarPDFActionPerformed
       generarPDF();
    }//GEN-LAST:event_botonGenerarPDFActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
    // Obtener los valores seleccionados en los campos de búsqueda
    String periodoDesde = (String) periodoDesde.getSelectedItem();
    String periodoHasta = (String) periodoHasta.getSelectedItem();
    String tipoTramite = (String) tipoTramite.getSelectedItem();

    // Realizar la búsqueda en la base de datos
    List<Tramite> tramitesEncontrados = buscarTramitesEnBaseDeDatos(periodoDesde, periodoHasta, tipoTramite);

    // Mostrar los trámites encontrados en la tabla
    mostrarTramitesEnTabla(tramitesEncontrados);

    }//GEN-LAST:event_botonBuscarActionPerformed

    private List<Tramite> buscarTramitesEnBaseDeDatos(String periodoDesde, String periodoHasta, String tipoTramite) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConexionPU"); 
    EntityManager em = emf.createEntityManager();

    // Construir la consulta JPQL para buscar trámites con los criterios especificados
    String jpql = "SELECT t FROM Tramite t WHERE t.fechaTramite BETWEEN :desde AND :hasta AND t.tipoTramite = :tipo";

    Query query = em.createQuery(jpql);
    // Asignar los parámetros de la consulta
    query.setParameter("desde", periodoDesde);
    query.setParameter("hasta", periodoHasta);
    query.setParameter("tipo", tipoTramite);

    // Ejecutar la consulta y obtener los resultados
    List<Tramite> resultado = query.getResultList();

    em.close();
    emf.close();

    return resultado;
}
    

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reportes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonGenerarPDF;
    private javax.swing.JButton botonLimpiar;
    private javax.swing.JButton botonRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField nombreSimilar;
    private javax.swing.JComboBox<String> periodoDesde;
    private javax.swing.JComboBox<String> periodoHasta;
    private javax.swing.JTable tablaReporte;
    private javax.swing.JComboBox<String> tipoTramite;
    private javax.swing.JLabel txtNombreSimilar;
    private javax.swing.JLabel txtPeriodo;
    private javax.swing.JLabel txtTipoTramite;
    // End of variables declaration//GEN-END:variables
}
